def split_code_into_chunks(code: str, lines_per_chunk: int = 700) -> list:
    """Split code into chunks of specified line count"""
    lines = code.splitlines()
    chunks = []

    for i in range(0, len(lines), lines_per_chunk):
        chunk = lines[i:i + lines_per_chunk]
        chunks.append('\n'.join(chunk))

    return chunks

def get_progress_bar(current: int, total: int, length: int = 20) -> str:
    if total == 0:
        return "░" * length
    filled_length = int((current / total) * length)
    return "█" * filled_length + "░" * (length - filled_length)
