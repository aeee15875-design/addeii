import asyncio
import re
from cerebras_client import client_manager
from config import CEREBRAS_MODEL

async def clean_code_chunk(chunk: str, chunk_index: int, total_chunks: int) -> str:
    """Clean a single chunk of Lua code"""
    try:
        # Remove markdown code block syntax if present
        chunk = re.sub(r'```(?:lua)?\s*\n?', '', chunk)
        chunk = chunk.strip()

        prompt = f"""Clean this Lua code chunk (Part {chunk_index + 1}/{total_chunks}). Rename variables to meaningful names and simplify the code structure. Return only the cleaned code without explanations.

{chunk}"""

        def call_cerebras():
            response = client_manager.make_request(
                model=CEREBRAS_MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a code deobfuscation assistant. Return only clean code without explanations or markdown formatting."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.1,
                max_tokens=8000,
                top_p=0.8
            )
            return response.choices[0].message.content

        deobfuscated = await asyncio.to_thread(call_cerebras)
        # Remove markdown code block syntax from output if present
        deobfuscated = re.sub(r'```(?:lua)?\s*\n?', '', deobfuscated)
        deobfuscated = deobfuscated.replace('``````', '').strip()
        return deobfuscated

    except Exception as e:
        raise Exception(f"Chunk {chunk_index + 1} cleaning failed: {str(e)}")

async def clean_lua_code(code: str, progress_callback=None) -> str:
    """Clean Lua code by processing in chunks and merging"""
    try:
        from utils import split_code_into_chunks

        lines = code.splitlines()
        total_lines = len(lines)

        if total_lines <= 700:
            # Single chunk process (reuse above function for simplicity)
            deobfuscated = await clean_code_chunk(code, 0, 1)
            if progress_callback:
                await progress_callback(1, 1, "Completed processing single chunk")
            return deobfuscated

        chunks = split_code_into_chunks(code, lines_per_chunk=700)
        total_chunks = len(chunks)
        deobfuscated_chunks = []

        for i, chunk in enumerate(chunks):
            if progress_callback:
                await progress_callback(i, total_chunks, f"Processing chunk {i + 1}/{total_chunks}...")
            deobfuscated_chunk = await clean_code_chunk(chunk, i, total_chunks)
            deobfuscated_chunks.append(deobfuscated_chunk)
            if progress_callback:
                await progress_callback(i + 1, total_chunks, f"Completed chunk {i + 1}/{total_chunks}")
            if i < total_chunks - 1:
                await asyncio.sleep(0.3)

        if progress_callback:
            await progress_callback(total_chunks, total_chunks, "Merging chunks...")

        merged_code = '\n\n'.join(deobfuscated_chunks)
        return merged_code

    except Exception as e:
        raise Exception(f"Cleaning failed: {str(e)}")
