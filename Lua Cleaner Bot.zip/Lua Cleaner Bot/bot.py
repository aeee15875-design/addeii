import discord
from discord.ext import commands
from discord import app_commands
from config import *
from cerebras_client import test_cerebras_connection
import commands as bot_commands


intents = discord.Intents.default()
bot = commands.Bot(command_prefix=BOT_PREFIX, intents=intents)

@bot.event
async def on_ready():
    print(f'{bot.user} has connected to Discord!')
    try:
        guild = discord.Object(id=GUILD_ID)
        bot.tree.copy_global_to(guild=guild)
        synced = await bot.tree.sync(guild=guild)
        print(f"Synced {len(synced)} command(s) to guild {GUILD_ID}")
    except Exception as e:
        print(f"Failed to sync commands: {e}")
    print(f'Bot is ready! Using Cerebras AI: {CEREBRAS_MODEL}')

@bot.tree.command(name="clean", description="Clean a single obfuscated Lua file")
@app_commands.describe(file="Upload a .lua file to clean")
async def clean(interaction: discord.Interaction, file: discord.Attachment):
    await bot_commands.clean_single_command(interaction, file, bot)

@bot.tree.command(name="cleanzip", description="Clean multiple Lua files from a ZIP archive")
@app_commands.describe(file="Upload a .zip file containing Lua files")
async def cleanzip(interaction: discord.Interaction, file: discord.Attachment):
    await bot_commands.clean_zip_command(interaction, file, bot)

@bot.tree.command(name="help", description="Show help for the Lua cleaner bot")
async def help_cmd(interaction: discord.Interaction):
    await bot_commands.help_command(interaction, bot)

@bot.tree.command(name="stats", description="View bot statistics")
async def stats(interaction: discord.Interaction):
    await bot_commands.stats_command(interaction, bot)

@bot.tree.command(name="ping", description="Check bot latency")
async def ping(interaction: discord.Interaction):
    await bot_commands.ping_command(interaction)

@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    print(f"Discord command error: {str(error)}")  # Add logging
    embed = discord.Embed(
        title="❌ Error",
        description=f"**Error Details:**\n```{str(error)[:500]}```\n\nPlease try again or contact support",
        color=COLOR_ERROR
    )
    if interaction.response.is_done():
        await interaction.followup.send(embed=embed, ephemeral=True)
    else:
        await interaction.response.send_message(embed=embed, ephemeral=True)

if __name__ == "__main__":
    print("=" * 50)
    print("🚀 Starting Lua Cleaner Bot (Chunked Processing)")
    print(f"📡 Model: {CEREBRAS_MODEL}")
    print(f"📦 Chunk Size: 700 lines")
    print("=" * 50)

    if not test_cerebras_connection():
        print("ERROR: Cannot connect to Cerebras API!")
        exit(1)

    bot.run(DISCORD_TOKEN)
