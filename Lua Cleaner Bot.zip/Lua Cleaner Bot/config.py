# ============================================
# Configuration File for Lua Cleaner Bot
# Using Cerebras API (ULTRA FAST & FREE)
# ============================================

# Discord Bot Configuration
DISCORD_TOKEN = "MTQyNjczNjMwNjY5NTk2Njc5MA.Gef0cC.cEFMrK6oTAhL9o0GSrlprl1jg6ZNtEiG_nUeSE"  # Replace with your token
GUILD_ID = 1348526437589848147  # Replace with your server/guild ID

# Cerebras API Configuration (FREE with high limits!)
CEREBRAS_API_KEYS = [
    "csk-8m82y9j2jmmtewv8ykpdhmtxknneddwkvccf8w5yy28ye3x3",  # Primary key
    "csk-fyw54xrd629rr2krwm843ww5yf4r8vjjywe59rcn5m3x95tx"
]
CEREBRAS_MODEL = "llama-3.3-70b"  # Best balance of speed and quality

# Available Cerebras models (ALL FREE):
# - "llama3.1-70b" - Best overall (Recommended)
# - "llama3.1-8b" - Fastest, good for simple tasks
# - "llama3.1-405b" - For very complex tasks (if available)

# Bot Settings
BOT_PREFIX = "/"
BOT_VERSION = "2.0"
API_BRANDING = "Cerebras (llama-3.3-70b)"

# File Processing Limits
MAX_SINGLE_FILE_SIZE = 50000   # 50KB
MAX_ZIP_FILES = 15             # 15 files max

# Optimized Prompt for Cerebras
DEOBFUSCATION_PROMPT = """You are deobfuscating Lua code. Follow these steps exactly:

Step 1: Identify all L#_# and A#_# variables
Step 2: Determine what each variable stores by tracing its usage
Step 3: Replace with descriptive names (playerId, cost, amount, phoneData, chargeType)
Step 4: Simplify call chains - remove intermediate assignments
Step 5: Inline function declarations into RegisterNetEvent calls

Rules:
- Keep ALL string literals exactly the same
- Keep ALL math formulas exactly the same
- Only change variable names and call structure

Example:
L0_1 = RegisterNetEvent
L1_1 = "event"
function L2_1(A0_2, A1_2)
    L2_2 = source
    L3_2 = A0_2 * A1_2
end
L0_1(L1_1, L2_1)

Output:
RegisterNetEvent("event", function(amount, multiplier)
    local playerId = source
    local result = amount * multiplier
end)

Now deobfuscate:
{CODE}"""

# Embed Colors (Discord color codes)
COLOR_PROCESSING = 0x3498db  # Blue
COLOR_SUCCESS = 0x2ecc71     # Green
COLOR_ERROR = 0xe74c3c       # Red
COLOR_WARNING = 0xf39c12     # Orange
COLOR_INFO = 0x9b59b6        # Purple

# Messages
ERROR_MESSAGES = {
    'invalid_lua': "Please upload a `.lua` file!",
    'invalid_zip': "Please upload a `.zip` file!",
    'file_too_large': f"File too large! Maximum 50KB per file.",
    'too_many_files': f"Too many files! Maximum 15 files per ZIP.",
    'no_lua_files': "No .lua files found in the ZIP!",
    'processing_failed': "No files could be processed successfully!",
}

SUCCESS_MESSAGES = {
    'single_complete': "Cleaning Complete!",
    'batch_complete': "Zip Cleaning Complete!",
}