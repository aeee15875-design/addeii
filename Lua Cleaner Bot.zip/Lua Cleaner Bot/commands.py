import discord
from discord import app_commands
from config import *
from clean_lua import clean_lua_code
import io
import time
import zipfile

async def clean_single_command(interaction: discord.Interaction, file: discord.Attachment, bot):
    if not file.filename.endswith('.lua'):
        error_embed = discord.Embed(
            title="❌ Invalid File Type",
            description=ERROR_MESSAGES['invalid_lua'],
            color=COLOR_ERROR
        )
        error_embed.set_footer(text="Only .lua files are supported")
        await interaction.response.send_message(embed=error_embed, ephemeral=True)
        return

    start_embed = discord.Embed(
        title="🔄 Processing Your File",
        description=f"**File:** `{file.filename}`\n**Size:** {file.size:,} bytes ({file.size // 1000}KB)",
        color=COLOR_PROCESSING
    )
    start_embed.add_field(name="📥 Current Stage", value="⏳ Downloading file from Discord...", inline=False)
    start_embed.add_field(name="⏭️ Next Steps", value="1️⃣ File validation\n2️⃣ Chunk division\n3️⃣ AI analysis (per chunk)\n4️⃣ Merging results\n5️⃣ Final delivery", inline=False)
    start_embed.set_footer(text="⏱️ Large files may take longer due to chunked processing")

    await interaction.response.send_message(embed=start_embed, ephemeral=True)

    start_time = time.time()

    try:
        file_content = await file.read()
        code = file_content.decode('utf-8')

        total_lines = len(code.splitlines())

        # Allow larger files with chunking
        if len(code) > MAX_SINGLE_FILE_SIZE * 10:
            error_embed = discord.Embed(
                title="❌ File Too Large",
                description=f"File too large! Maximum {(MAX_SINGLE_FILE_SIZE * 10) // 1000}KB per file.",
                color=COLOR_ERROR
            )
            error_embed.set_footer(text="Please split your file into smaller parts")
            await interaction.edit_original_response(embed=error_embed)
            return

        num_chunks = (total_lines + 699) // 700

        async def update_progress(current_chunk, total_chunks, status):
            from utils import get_progress_bar

            progress_percent = int((current_chunk / total_chunks) * 100) if total_chunks > 0 else 0
            progress_bar = get_progress_bar(current_chunk, total_chunks)

            processing_embed = discord.Embed(
                title="🤖 AI Processing in Progress...",
                description=f"**Current File:** `{file.filename}`",
                color=COLOR_WARNING
            )
            processing_embed.add_field(
                name="📄 File Analysis",
                value=f"**Total Lines:** `{total_lines}`\n**Chunks:** `{num_chunks}` (700 lines each)\n**Status:** {status}",
                inline=False
            )
            progress_bar = f"`[{get_progress_bar(current_chunk, total_chunks)}]` {progress_percent}%"
            processing_embed.add_field(
                name="📊 Overall Progress",
                value=f"{progress_bar}\n**Chunk {current_chunk}/{total_chunks}** completed",
                inline=False
            )
            processing_embed.add_field(
                name="🔍 AI Operations",
                value="• Pattern recognition\n• Variable renaming\n• Syntax cleaning\n• Code simplification",
                inline=True
            )
            elapsed = time.time() - start_time
            processing_embed.add_field(name="⏱️ Time", value=f"**Elapsed:** `{elapsed:.1f}s`\n**Stage:** Chunk processing", inline=True)
            processing_embed.set_footer(text="⏱️ Processing large file in chunks for best results")

            try:
                await interaction.edit_original_response(embed=processing_embed)
            except:
                pass

        deobfuscated = await clean_lua_code(code, progress_callback=update_progress)

        elapsed_time = time.time() - start_time

        success_embed = discord.Embed(
            title=f"✅ {SUCCESS_MESSAGES['single_complete']}",
            description=f"Successfully cleaned your Lua file!",
            color=COLOR_SUCCESS
        )

        success_embed.add_field(name="📁 Files", value=f"**Original:** `{file.filename}`\n**Cleaned:** `clean_{file.filename}`", inline=False)

        original_lines = len(code.splitlines())
        cleaned_lines = len(deobfuscated.splitlines())
        line_diff = cleaned_lines - original_lines
        line_diff_percent = ((cleaned_lines - original_lines) / original_lines * 100) if original_lines > 0 else 0

        success_embed.add_field(
            name="📊 Code Statistics",
            value=(
                f"**Original Lines:** `{original_lines}`\n"
                f"**Cleaned Lines:** `{cleaned_lines}` ({line_diff:+d}, {line_diff_percent:+.1f}%)\n"
                f"**Chunks Processed:** `{num_chunks}`\n"
                f"**Original Size:** `{len(code):,}` chars\n"
                f"**Cleaned Size:** `{len(deobfuscated):,}` chars"
            ),
            inline=True,
        )

        success_embed.add_field(
            name="⚡ Performance",
            value=(
                f"**Time Taken:** `{elapsed_time:.2f}s`\n"
                f"**Processing Speed:** `{int(original_lines / elapsed_time) if elapsed_time > 0 else 0}` lines/s\n"
                f"**Version:** `Ezy V2`"
            ),
            inline=True,
        )

        success_embed.add_field(
            name="🎯 Improvements Applied",
            value="✓ Variables renamed to meaningful names\n✓ Code structure simplified\n✓ Obfuscation patterns removed\n✓ Syntax cleaned and optimized\n✓ Chunked processing for large files",
            inline=False,
        )

        success_embed.add_field(name="💾 Download Ready", value="Your cleaned file is attached below!", inline=False)

        success_embed.set_footer(text=f"Processed by {bot.user.name} • Powered by {API_BRANDING}")
        success_embed.timestamp = discord.utils.utcnow()

        output_file = discord.File(io.BytesIO(deobfuscated.encode('utf-8')), filename=f"clean_{file.filename}")

        # First send the cleaned file
        
        # Then send an embed mentioning the user
        success_embed = discord.Embed(
            title="✨ Code Successfully Cleaned",
            description=(
                f"📎 **File:** `clean_{file.filename}`\n"
                f"👤 **Cleaned by:** {interaction.user.mention}\n\n"
                "✅ **Status:** File attached above"
            ),
            color=COLOR_SUCCESS
        )
        success_embed.set_footer(text=f"Processed by {bot.user.name} • Powered by {API_BRANDING}")
        success_embed.timestamp = discord.utils.utcnow()
        
        await interaction.followup.send(file=output_file, embed=success_embed, ephemeral=True)
        
    except Exception as e:
        print(f"Error processing single file {file.filename}: {str(e)}")  # Add logging
        error_embed = discord.Embed(
            title="❌ Processing Error",
            description=f"**Error Details:**\n```{str(e)[:500]}```\n\nPlease try again or contact support",
            color=COLOR_ERROR
        )
        error_embed.set_footer(text="Error logged for debugging")
        await interaction.edit_original_response(embed=error_embed)

async def clean_zip_command(interaction: discord.Interaction, file: discord.Attachment, bot):
    import io
    import zipfile
    import time

    if not file.filename.endswith('.zip'):
        error_embed = discord.Embed(
            title="❌ Invalid File Type",
            description=ERROR_MESSAGES['invalid_zip'],
            color=COLOR_ERROR
        )
        error_embed.set_footer(text="Only .zip files are supported")
        await interaction.response.send_message(embed=error_embed, ephemeral=True)
        return

    start_embed = discord.Embed(
        title="📦 Processing ZIP Archive",
        description=f"**File:** `{file.filename}`\n**Size:** {file.size:,} bytes ({file.size // 1000}KB)",
        color=COLOR_PROCESSING
    )
    start_embed.add_field(name="📥 Current Stage", value="⏳ Extracting and analyzing ZIP contents...", inline=False)
    start_embed.set_footer(text="⏱️ Zip processing with chunked files may take longer")

    await interaction.response.send_message(embed=start_embed, ephemeral=True)

    start_time = time.time()

    try:
        zip_content = await file.read()
        zip_buffer = io.BytesIO(zip_content)

        deobfuscated_files = {}
        lua_files = []

        with zipfile.ZipFile(zip_buffer, 'r') as zip_ref:
            lua_files = [f for f in zip_ref.namelist() if f.endswith('.lua')]

            if not lua_files:
                error_embed = discord.Embed(
                    title="❌ No Lua Files Found",
                    description=ERROR_MESSAGES['no_lua_files'],
                    color=COLOR_ERROR
                )
                await interaction.edit_original_response(embed=error_embed)
                return

            if len(lua_files) > MAX_ZIP_FILES:
                error_embed = discord.Embed(
                    title="❌ Too Many Files",
                    description=ERROR_MESSAGES['too_many_files'],
                    color=COLOR_ERROR
                )
                await interaction.edit_original_response(embed=error_embed)
                return

            for i, lua_file in enumerate(lua_files, 1):
                try:
                    with zip_ref.open(lua_file) as f:
                        code = f.read().decode('utf-8')

                    if len(code) > MAX_SINGLE_FILE_SIZE * 10:
                        continue

                    progress_percent = int((i / len(lua_files)) * 100)
                    progress_bar = "█" * int((i / len(lua_files)) * 20) + "░" * (20 - int((i / len(lua_files)) * 20))

                    num_chunks = (len(code.splitlines()) + 699) // 700

                    progress_embed = discord.Embed(
                        title="🤖 AI Processing ZIP Files...",
                        description=f"**Current File:** `{lua_file}`\n**Lines:** `{len(code.splitlines())}`\n**Chunks:** `{num_chunks}`",
                        color=COLOR_WARNING,
                    )
                    progress_embed.add_field(
                        name="📊 Overall Progress",
                        value=f"``````\n**{i}/{len(lua_files)}** files • **{progress_percent}%** completed",
                        inline=False,
                    )

                    await interaction.edit_original_response(embed=progress_embed)

                    deobfuscated = await clean_lua_code(code)
                    deobfuscated_files[lua_file] = deobfuscated

                except Exception as e:
                    print(f"Error processing {lua_file}: {e}")
                    continue

        if not deobfuscated_files:
            error_embed = discord.Embed(
                title="❌ Processing Failed",
                description=ERROR_MESSAGES['processing_failed'],
                color=COLOR_ERROR,
            )
            await interaction.edit_original_response(embed=error_embed)
            return

        output_zip = io.BytesIO()
        with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zip_out:
            for filename, content in deobfuscated_files.items():
                zip_out.writestr(filename, content)

        output_zip.seek(0)
        elapsed_time = time.time() - start_time

        success_embed = discord.Embed(
            title=f"✅ {SUCCESS_MESSAGES['batch_complete']}",
            description=f"Successfully processed ZIP archive with chunked processing!",
            color=COLOR_SUCCESS,
        )
        success_embed.add_field(name="📦 Archive Files", value=f"**Original:** `{file.filename}`\n**Cleaned:** `clean_{file.filename}`", inline=False)

        success_rate = (len(deobfuscated_files) / len(lua_files) * 100) if len(lua_files) > 0 else 0
        success_embed.add_field(
            name="📊 Statistics",
            value=(
                f"**Total Files:** `{len(lua_files)}`\n"
                f"**Successful:** `{len(deobfuscated_files)}` ({success_rate:.1f}%)\n"
                f"**Total Time:** `{elapsed_time:.2f}s`"
            ),
            inline=True,
        )

        success_embed.set_footer(text=f"Processed by {bot.user.name} • Powered by {API_BRANDING}")
        success_embed.timestamp = discord.utils.utcnow()

        output_file = discord.File(output_zip, filename=f"clean_{file.filename}")

        await interaction.edit_original_response(embed=success_embed)
        await interaction.followup.send(file=output_file, ephemeral=True)

    except Exception as e:
        print(f"Error processing ZIP file {file.filename}: {str(e)}")  # Add logging
        error_embed = discord.Embed(
            title="❌ Processing Error",
            description=f"**Error Details:**\n```{str(e)[:500]}```\n\nPlease try again or contact support",
            color=COLOR_ERROR,
        )
        error_embed.set_footer(text="Error logged for debugging")
        await interaction.edit_original_response(embed=error_embed)

async def help_command(interaction: discord.Interaction, bot):
    embed = discord.Embed(
        title="🤖 Lua Code Cleaner Bot",
        description="AI-powered tool to clean obfuscated Lua code using Cerebras AI with chunked processing",
        color=COLOR_INFO,
    )
    embed.add_field(
        name="📝 Commands",
        value=(
            "`/clean` - Clean a single .lua file (supports large files)\n"
            "`/cleanzip` - Clean multiple files from a .zip\n"
            "`/help` - Show this help message\n"
            "`/stats` - View bot statistics\n"
            "`/ping` - Check bot status"
        ),
        inline=False,
    )
    embed.add_field(
        name="✨ Features",
        value=(
            "• Renames obfuscated variables\n"
            "• Simplifies complex code structures\n"
            "• Chunked processing (700 lines per chunk)\n"
            "• Zip processing for multiple files\n"
            "• Handles large files efficiently\n"
            "• Developed by Marco"
        ),
        inline=False,
    )
    embed.add_field(
        name="🔧 Processing Method",
        value=(
            "Large files are automatically split into 700-line chunks, "
            "processed separately by AI, then merged back into a single file. "
            "This ensures consistent quality even for very large scripts."
        ),
        inline=False,
    )
    embed.set_footer(text=f"Powered by {API_BRANDING}")

    await interaction.response.send_message(embed=embed, ephemeral=True)

async def stats_command(interaction: discord.Interaction, bot):
    embed = discord.Embed(title="📊 Bot Statistics", color=COLOR_INFO)

    embed.add_field(name="🌐 Servers", value=f"`{len(bot.guilds)}`", inline=True)
    embed.add_field(name="👥 Users", value=f"`{len(bot.users)}`", inline=True)
    embed.add_field(name="🏓 Latency", value=f"`{round(bot.latency * 1000)}ms`", inline=True)
    embed.add_field(name="🤖 AI Model", value=f"`{CEREBRAS_MODEL}`", inline=False)
    embed.add_field(name="📦 Chunk Size", value="`700 lines`", inline=True)
    embed.add_field(name="🔄 Processing", value="`Chunked Mode`", inline=True)

    embed.set_footer(text=f"Bot Version {BOT_VERSION} • {API_BRANDING}")
    embed.timestamp = discord.utils.utcnow()

    await interaction.response.send_message(embed=embed, ephemeral=True)

async def ping_command(interaction: discord.Interaction):
    latency = round(interaction.client.latency * 1000)

    if latency < 100:
        color = COLOR_SUCCESS
        status = "✅ Excellent"
    elif latency < 200:
        color = COLOR_WARNING
        status = "⚠️ Good"
    else:
        color = COLOR_ERROR
        status = "🔴 Slow"

    embed = discord.Embed(title="🏓 Pong!", description=f"Bot latency: **{latency}ms**", color=color)
    embed.add_field(name="Status", value=status, inline=False)

    await interaction.response.send_message(embed=embed, ephemeral=True)
