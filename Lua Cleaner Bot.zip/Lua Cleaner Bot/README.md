# Lua Cleaner Bot V2

A powerful Discord bot designed to clean and deobfuscate Lua code, making it more readable and maintainable. This bot can process both individual `.lua` files and `.zip` archives containing multiple Lua files.

## ✨ Features

- **Code Deobfuscation**: Renames obfuscated variables to meaningful names
- **Code Simplification**: Removes unnecessary complexity and improves structure
- **Large File Support**: Processes files in chunks (700 lines each) for optimal performance
- **Batch Processing**: Handles ZIP archives containing multiple Lua files
- **User-Friendly**: Provides detailed progress updates and statistics
- **Efficient**: Uses chunked processing to handle large files effectively

## 🚀 Installation

1. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Configure your bot by editing `config.py` with your Discord bot token and other settings.

3. Run the bot:
   ```bash
   python bot.py
   ```

## 🛠️ Commands

### `/clean [file]`
Cleans a single Lua file. The bot will process the file and return a cleaned version.

### `/clean_zip [zip_file]`
Processes a ZIP archive containing multiple Lua files. The bot will clean all Lua files in the archive and return them in a new ZIP file.

### `/help`
Shows the help menu with available commands and usage information.

### `/ping`
Checks if the bot is online and responsive.

### `/stats`
Displays bot statistics and usage information.

## 🔧 Configuration

Edit the `config.py` file to configure the following settings:

- `DISCORD_TOKEN`: Your Discord bot token
- `CEREBRAS_MODEL`: The Cerebras model to use for code cleaning
- `MAX_SINGLE_FILE_SIZE`: Maximum size for single file processing
- `MAX_ZIP_FILE_SIZE`: Maximum size for ZIP file processing
- `MAX_FILES_IN_ZIP`: Maximum number of files allowed in a ZIP archive

## 📁 Project Structure

- `bot.py`: Main bot file containing the Discord client setup and event handlers
- `commands.py`: Contains all the slash commands and their logic
- `clean_lua.py`: Handles the actual code cleaning functionality
- `cerebras_client.py`: Client for interacting with the Cerebras API
- `utils.py`: Utility functions and helpers
- `config.py`: Configuration settings
- `requirements.txt`: Python dependencies
