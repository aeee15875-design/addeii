from cerebras.cloud.sdk import Cerebras
from config import CEREBRAS_API_KEYS, CEREBRAS_MODEL
import itertools
import time

class CerebrasClientManager:
    def __init__(self, api_keys):
        self.api_keys = api_keys
        self.clients = [Cerebras(api_key=key) for key in api_keys]
        self.key_cycle = itertools.cycle(range(len(self.clients)))
        self.current_key_index = next(self.key_cycle)
        self.rate_limit_cooldowns = [0] * len(self.clients)  # Track cooldown times for each key

    def get_next_client(self):
        """Get the next available client, skipping those in cooldown"""
        current_time = time.time()
        attempts = 0
        max_attempts = len(self.clients)

        while attempts < max_attempts:
            client_index = self.current_key_index
            if current_time >= self.rate_limit_cooldowns[client_index]:
                # Key is not in cooldown, use it
                self.current_key_index = next(self.key_cycle)
                return self.clients[client_index], client_index
            else:
                # Key is in cooldown, try next
                self.current_key_index = next(self.key_cycle)
                attempts += 1

        # All keys are in cooldown, wait for the shortest cooldown
        min_cooldown = min(self.rate_limit_cooldowns)
        wait_time = max(0, min_cooldown - current_time)
        if wait_time > 0:
            time.sleep(wait_time)
        return self.get_next_client()  # Retry after waiting

    def set_cooldown(self, key_index, cooldown_seconds=60):
        """Set cooldown for a specific key"""
        self.rate_limit_cooldowns[key_index] = time.time() + cooldown_seconds

    def make_request(self, **kwargs):
        """Make a request with automatic key rotation on rate limit"""
        last_exception = None

        for attempt in range(len(self.clients)):
            try:
                client, key_index = self.get_next_client()
                print(f"[DEBUG] Using API key {key_index + 1}/{len(self.clients)} for request")
                response = client.chat.completions.create(**kwargs)
                print(f"[DEBUG] Request successful with key {key_index + 1}")
                return response
            except Exception as e:
                error_str = str(e).lower()
                if ('rate limit' in error_str or '429' in error_str or 'rate_limit_exceeded' in error_str):
                    # Rate limit hit, set cooldown for this key and try next
                    print(f"[DEBUG] Rate limit hit on key {key_index + 1}, setting cooldown and trying next key")
                    self.set_cooldown(key_index, 60)  # 60 second cooldown
                    last_exception = e
                    continue
                else:
                    # Other error, re-raise immediately
                    print(f"[DEBUG] Non-rate-limit error on key {key_index + 1}: {e}")
                    raise e

        # All keys hit rate limit
        print(f"[DEBUG] All {len(self.clients)} keys hit rate limit")
        raise last_exception or Exception("All API keys are rate limited")

# Global client manager
client_manager = CerebrasClientManager(CEREBRAS_API_KEYS)

def test_cerebras_connection():
    """Test API connection using the first available key"""
    try:
        client, _ = client_manager.get_next_client()
        response = client.chat.completions.create(
            model=CEREBRAS_MODEL,
            messages=[{"role": "user", "content": "test"}],
            max_tokens=10
        )
        print(f"✅ API connection successful!")
        print(f"Using model: {CEREBRAS_MODEL}")
        print(f"Available API keys: {len(CEREBRAS_API_KEYS)}")
        return True
    except Exception as e:
        print(f"❌ API connection failed: {e}")
        print("Please check your Cerebras API keys and internet connection")
        return False
